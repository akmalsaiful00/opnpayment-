<fieldset id="omise-form-konbini">
    <p class="form-row form-row-wide omise-required-field">
	    <label for="omise_konbini_name"><?php _e( 'Name', 'omise' ); ?></label>
	    <input id="omise_konbini_name" class="input-text" name="omise_konbini_name" type="text" maxlength="10" autocomplete="off">
    </p>

    <p class="form-row form-row-wide omise-required-field">
	    <label for="omise_konbini_email"><?php _e( 'Email', 'omise' ); ?></label>
	    <input id="omise_konbini_email" class="input-text" name="omise_konbini_email" type="text" maxlength="50" autocomplete="off">
    </p>

    <p class="form-row form-row-wide omise-required-field">
	    <label for="omise_konbini_phone"><?php _e( 'Phone', 'omise' ); ?></label>
	    <input id="omise_konbini_phone" class="input-text" name="omise_konbini_phone" type="text" maxlength="11" autocomplete="off">
    </p>
</fieldset>
